﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _184517IfChallenges
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int num1;
        int num2;
        int num3;
        int year;
        string letter;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnNumber_Click(object sender, RoutedEventArgs e) 
        {
           
            string output1 = "";
            int.TryParse(txtNumber1.Text, out num1);
            int.TryParse(txtNumber2.Text, out num2);
            if (num1 > num2)
            {
                output1 = "Number 1 is greater than 2";
            }
            else
            {
                output1 = "Number 2 is greater than 1";
            }
            int.TryParse(txtNumber3.Text, out num3);
            if (num1 > num2 && num1 > num3)
            {
                output1 = output1 + Environment.NewLine + "Number 1 is greater than 2 and 3";
            }
            else if (num2 > num1 && num2 > num3)
            {
                output1 = output1 + Environment.NewLine + "Number 2 is greater than 1 and 3";
            }
            else
            {
                output1 = output1 + Environment.NewLine + "Number 3 is greater than 1 and 2";
            }
            if (num1 > 0)
            {
                output1 = output1 + Environment.NewLine + "Number 1 is positive";
            }
            else if (num1 < 0)
            {
                output1 = output1 + Environment.NewLine + "Number 1 is negative";
            }
            else
            {
                output1 = output1 + Environment.NewLine + "Number 1 is zero";
            }
            if ((num1 % 5) == 0 && (num1 % 11) ==0)
            {
                output1 = output1 + Environment.NewLine + "Number 1 is divisible by 5 and 11";
            }
            else
            {
                output1 = output1 + Environment.NewLine + "Number 1 is not divisible by 5 and 11";
            }
            if((num1 % 2) == 0)
            {
                output1 = output1 + Environment.NewLine + "Number 1 is even";
            }
            else
            {
                output1 = output1 + Environment.NewLine + "Number 1 is odd";
            }
            lblOutputNumber.Content = output1;
        }

        private void btnYear_Click(object sender, RoutedEventArgs e) 
        {
            string output2 = "";
            int.TryParse(txtYear.Text, out year);
            if((year % 4) == 0)
            {
                output2 = output2 + Environment.NewLine + "This is a leap year";
            }
            else
            {
                output2 = output2 + Environment.NewLine + "This is not a leap year";
            }
            lblOutputYear.Content = output2;
        }

        private void btnLetter_Click(object sender, RoutedEventArgs e) 
        {
            txtLetter.Text = txtLetter.Text.ToLower();

            char theLetter = txtLetter.Text[0];
            bool isVowel = false;
            if (theLetter == 'a')
            {
                isVowel = true;
            }
            else if (theLetter == 'e') 
            {
                isVowel = true;
            } 
            
            else if (theLetter == 'i') 
            {
                isVowel = true;
            }
            else if (theLetter == 'o') 
            {
                isVowel = true;
            }
            else if (theLetter == 'u') 
            {
                isVowel = true;
            }
            if(isVowel)
            {
                lblOutputLetter.Content = "Vowel";
            }
            else
            {
                lblOutputLetter.Content = "Consonant";
            }
        }

        private void btnCharacter_Click(object sender, RoutedEventArgs e) 
        {

        }
        
    }
}
